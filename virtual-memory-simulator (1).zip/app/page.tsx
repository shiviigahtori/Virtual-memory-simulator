"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import SimulationPanel from "@/components/simulation/simulation-panel"
import VisualizationPanel from "@/components/simulation/visualization-panel"
import ComparisonPanel from "@/components/simulation/comparison-panel"
import EducationalPanel from "@/components/simulation/educational-panel"
import { MemoryProvider } from "@/context/memory-context"

export default function VirtualMemoryManager() {
  const [activeTab, setActiveTab] = useState("visualization")

  return (
    <MemoryProvider>
      <div className="container mx-auto py-8">
        <h1 className="text-3xl font-bold mb-6 text-center">Advanced Virtual Memory Manager</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <SimulationPanel />
          <VisualizationPanel />
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="visualization">Access Pattern</TabsTrigger>
            <TabsTrigger value="comparison">Algorithm Comparison</TabsTrigger>
            <TabsTrigger value="educational">Educational</TabsTrigger>
            <TabsTrigger value="advanced">Advanced Features</TabsTrigger>
          </TabsList>

          <TabsContent value="visualization">
            <Card>
              <CardHeader>
                <CardTitle>Page Access Pattern</CardTitle>
                <CardDescription>Visualization of page accesses and memory state over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[500px] overflow-auto">
                  <VisualizationPanel detailed />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="comparison">
            <ComparisonPanel />
          </TabsContent>

          <TabsContent value="educational">
            <EducationalPanel />
          </TabsContent>

          <TabsContent value="advanced">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Memory Features</CardTitle>
                <CardDescription>Explore advanced virtual memory concepts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>TLB Simulation</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Translation Lookaside Buffer simulation coming soon. This will demonstrate how address
                        translation is accelerated.
                      </p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Thrashing Detection</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Thrashing detection and prevention mechanisms coming soon. This will show how systems detect and
                        recover from thrashing conditions.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MemoryProvider>
  )
}
