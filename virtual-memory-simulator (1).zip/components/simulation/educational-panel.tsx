"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useMemory } from "@/context/memory-context"

export default function EducationalPanel() {
  const { algorithm } = useMemory()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Educational Resources</CardTitle>
        <CardDescription>Learn about virtual memory management and page replacement algorithms</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="concepts">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="concepts">Key Concepts</TabsTrigger>
            <TabsTrigger value="algorithms">Algorithms</TabsTrigger>
            <TabsTrigger value="advanced">Advanced Topics</TabsTrigger>
          </TabsList>

          <TabsContent value="concepts" className="space-y-4">
            <div className="prose max-w-none">
              <h3>Virtual Memory Concepts</h3>

              <h4>What is Virtual Memory?</h4>
              <p>
                Virtual memory is a memory management technique that provides an idealized abstraction of the storage
                resources that are actually available on a given machine, creating the illusion to users of a very large
                (main) memory.
              </p>

              <h4>Paging</h4>
              <p>
                Paging is a memory management scheme that eliminates the need for contiguous allocation of physical
                memory. This scheme translates virtual addresses into physical addresses.
              </p>

              <h4>Page Faults</h4>
              <p>
                A page fault occurs when a program accesses a page that is mapped in the virtual address space, but not
                loaded in physical memory. The operating system must load the required page from secondary storage.
              </p>

              <h4>Working Set</h4>
              <p>
                The working set of a process is the collection of pages that it has referenced in the last n memory
                references (where n is the working set window). The working set is used to model the dynamic locality of
                a process.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="algorithms" className="space-y-4">
            <div className="prose max-w-none">
              <h3>Page Replacement Algorithms</h3>

              <h4>First-In-First-Out (FIFO)</h4>
              <p>
                The oldest page in memory is the victim. FIFO is simple to implement but suffers from the "Belady's
                anomaly" where increasing the number of frames can increase the number of page faults.
              </p>
              <pre className="bg-gray-100 p-2 rounded-md">
                {`function fifo(pages, frameCount) {
  let memory = []
  let pageFaults = 0
  
  for (const page of pages) {
    if (!memory.includes(page)) {
      pageFaults++
      if (memory.length >= frameCount) {
        memory.shift() // Remove oldest page
      }
      memory.push(page)
    }
  }
  
  return pageFaults
}`}
              </pre>

              <h4>Least Recently Used (LRU)</h4>
              <p>
                Replaces the page that has not been used for the longest period of time. LRU performs well in practice
                but requires tracking of when each page was last accessed.
              </p>
              <pre className="bg-gray-100 p-2 rounded-md">
                {`function lru(pages, frameCount) {
  let memory = []
  let pageFaults = 0
  
  for (const page of pages) {
    const index = memory.indexOf(page)
    if (index === -1) {
      pageFaults++
      if (memory.length >= frameCount) {
        memory.shift() // Remove least recently used
      }
    } else {
      memory.splice(index, 1) // Remove from current position
    }
    memory.push(page) // Add/move to most recently used
  }
  
  return pageFaults
}`}
              </pre>

              <h4>Optimal</h4>
              <p>
                Replaces the page that will not be used for the longest period of time in the future. This is
                theoretically optimal but requires future knowledge of the reference string.
              </p>

              <h4>Clock (Second Chance)</h4>
              <p>
                A more efficient implementation of FIFO that gives a second chance to pages before replacement. It uses
                a reference bit to determine if a page has been accessed recently.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <div className="prose max-w-none">
              <h3>Advanced Virtual Memory Concepts</h3>

              <h4>Translation Lookaside Buffer (TLB)</h4>
              <p>
                A TLB is a memory cache that stores recent translations of virtual memory to physical memory. It is used
                to reduce the time taken to access memory locations.
              </p>

              <h4>Thrashing</h4>
              <p>
                Thrashing occurs when a computer's virtual memory resources are overused, leading to a constant state of
                paging, inhibiting most application-level processing. This leads to poor performance of the computer.
              </p>

              <h4>Page Coloring</h4>
              <p>
                Page coloring is a technique used by operating systems to map virtual pages to physical frames to
                improve cache utilization.
              </p>

              <h4>Demand Paging vs. Pre-paging</h4>
              <p>
                Demand paging loads pages into memory only when they are accessed, while pre-paging tries to predict
                which pages will be needed and loads them in advance.
              </p>

              <h4>Memory Segmentation</h4>
              <p>
                Memory segmentation is a memory management technique in which memory is divided into segments of
                different sizes. Each segment represents a different type of data.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
