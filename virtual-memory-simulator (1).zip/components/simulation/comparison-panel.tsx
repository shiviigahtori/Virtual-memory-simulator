"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useMemory } from "@/context/memory-context"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts"
import { getAlgorithmDescription } from "@/lib/utils"

export default function ComparisonPanel() {
  const { comparisonData } = useMemory()

  return (
    <Card>
      <CardHeader>
        <CardTitle>Algorithm Comparison</CardTitle>
        <CardDescription>Performance comparison between different page replacement algorithms</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="h-80">
          {comparisonData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={comparisonData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="pageFaults" name="Page Faults" fill="#ef4444" />
                <Bar dataKey="pageHits" name="Page Hits" fill="#22c55e" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full">
              <p className="text-muted-foreground">Run a complete simulation to see algorithm comparison</p>
            </div>
          )}
        </div>

        <div className="mt-6">
          <h3 className="font-semibold mb-2">Efficiency Comparison</h3>
          <div className="space-y-2">
            {comparisonData.map((data, index) => (
              <div key={index} className="flex items-center">
                <span className="w-20">{data.name}:</span>
                <div className="flex-1 h-4 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-primary" style={{ width: `${data.efficiency}%` }}></div>
                </div>
                <span className="ml-2">{data.efficiency}%</span>
              </div>
            ))}
          </div>
        </div>

        {comparisonData.length > 0 && (
          <div className="mt-6 space-y-4">
            <h3 className="font-semibold">Algorithm Insights</h3>
            {comparisonData.map((data, index) => (
              <Card key={index} className="p-4">
                <h4 className="font-medium">{data.name}</h4>
                <p className="text-sm text-muted-foreground mt-1">{getAlgorithmDescription(data.name)}</p>
                <div className="flex gap-4 mt-2 text-sm">
                  <div>
                    Faults: <span className="font-medium text-red-500">{data.pageFaults}</span>
                  </div>
                  <div>
                    Hits: <span className="font-medium text-green-500">{data.pageHits}</span>
                  </div>
                  <div>
                    Efficiency: <span className="font-medium">{data.efficiency}%</span>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
